
import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS
import './App.css';

import BasicGrid from './pages/Basic';
import Customization from './pages/Customizations';
import ChangeDetection from './pages/ChangeDetection';
import Editing from './pages/Editing';


function App() {
  return (
    <>
      <header>
        {/* <img width={150} src='https://www.natwest.com/content/dam/natwest_com/navigation/header/natwest-logo.png' /> */}
        AG-GRID Demo
      </header>
      <div className="App">
        {/* <BasicGrid /> */}
        {/* <Customization/> */}
        {/* <ChangeDetection /> */}
        <Editing />
      </div>
    </>
  );
}

export default App;
