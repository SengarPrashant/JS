import React, { useCallback, useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';

const Customization = () => {
  const gridRef = useRef();
  const gridStyle = useMemo(() => ({ height: 'calc(100vh - 200px)', width: '100%' }), []);

  const filterParams = {
    comparator: (filterLocalDateAtMidnight, cellValue) => {
      var dateAsString = cellValue;
      if (dateAsString == null) return -1;
      var dateParts = dateAsString.split('/');
      var cellDate = new Date(
        Number(dateParts[2]),
        Number(dateParts[1]) - 1,
        Number(dateParts[0])
      );
      if (filterLocalDateAtMidnight.getTime() === cellDate.getTime()) {
        return 0;
      }
      if (cellDate < filterLocalDateAtMidnight) {
        return -1;
      }
      if (cellDate > filterLocalDateAtMidnight) {
        return 1;
      }
      return 0;
    },
    minValidYear: 2000,
    maxValidYear: 2021,
    inRangeFloatingFilterDateFormat: 'Do MMM YYYY',
  };

  const [columnDefs, setColumnDefs] = useState([
    {
      headerName: 'ID',
      maxWidth: 100,
      valueGetter: 'node.id',
      headerCheckboxSelection: true,
      checkboxSelection: true,
      cellRenderer: (props) => {
        if (props.value !== undefined) {
          return props.value;
        } else {
          return (
            <img src="https://www.ag-grid.com/example-assets/loading.gif" />
          );
        }
      },
    },
    { field: 'athlete', minWidth: 150, },
    {
      field: 'age', cellRenderer: (props) => {
        return <span style={{ color: props.value > 23 ? 'red' : 'green' }}>{props.value}</span>
      }
    },
    {
      field: 'country', minWidth: 150,
      filter: 'agTextColumnFilter',
      filterParams: {
        buttons: ['reset', 'apply'],
      },
    },
    {
      field: 'year',
      // cellClass: params => ['my-class-1','my-class-2'],
      cellStyle: params => {
        if (params.value > 2008) {
          return { color: 'whitesmoke', backgroundColor: 'green' };
        }
        return { color: '#333', backgroundColor: 'lightgrey' };;
      }
    },
    { field: 'date', minWidth: 150,
      filter: 'agDateColumnFilter',
      filterParams: filterParams,
    },
    { field: 'sport', minWidth: 150 },
    {
      field: 'gold',
      cellStyle: params => {
        if (params.value > 2) {
          return { color: 'whitesmoke', fontWeight: 'bold', backgroundColor: 'goldenrod' };
        }
        return { color: '#333', fontWeight: 'bold', backgroundColor: '#f28af8' };;
      }
    },
    { field: 'silver' },
    { field: 'bronze' },
    { field: 'total' },
  ]);


  const defaultColDef = useMemo(() => {
    return {
      filter: true,
      floatingFilter: true,
      flex: 1,
      resizable: true,
      minWidth: 100,
    };
  }, []);

  const getRowStyle = params => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: '#e2f3ff' };
    }
  };

  


  const onGridReady = useCallback((params) => {
    fetch('https://www.ag-grid.com/example-assets/olympic-winners.json')
      .then((resp) => resp.json())
      .then((data) => {

        const dataSource = {
          rowCount: undefined,
          getRows: (params) => {
            console.log('params', params)
            console.log(
              'asking for ' + params.startRow + ' to ' + params.endRow
            );

            // At this point in your code, you would call the server.
            // To make the demo look real, wait for 500ms before returning
            setTimeout(function () {
              // take a slice of the total rows
              const rowsThisPage = data.slice(params.startRow, params.endRow);
              // if on or after the last page, work out the last row.
              let lastRow = -1;
              if (data.length <= params.endRow) {
                lastRow = data.length;
              }
              // call the success callback
              params.successCallback(rowsThisPage, lastRow);
            }, 500);
          },
        };

        params.api.setDatasource(dataSource);
      });
  }, []);

  return (
    <div style={gridStyle} className="ag-theme-alpine">
      <AgGridReact
        getRowStyle={getRowStyle}
        columnDefs={columnDefs}
        defaultColDef={defaultColDef}
        rowBuffer={10} //10 rows before the first visible row and 10 rows after the last visible row
        rowSelection={'multiple'}
        rowModelType={'infinite'}
        cacheBlockSize={100}
        cacheOverflowSize={2} // no of rows displayed with loader
        maxConcurrentDatasourceRequests={1}
        infiniteInitialRowCount={100}
        maxBlocksInCache={2}
        onGridReady={onGridReady}
      //rowHeight={30}
      ></AgGridReact>
    </div>
  );
};

export default Customization;