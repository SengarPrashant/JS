import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component
import axios from 'axios';

const BasicGrid = () => {

    const gridRef = useRef(); // Optional - for accessing Grid's API
    const [rowData, setRowData] = useState([]); // Set rowData to Array of Objects, one Object per Row

    // Each Column Definition results in one Column.
    const [columnDefs, setColumnDefs] = useState([
        { field: 'name.common', filter: true },
        { field: 'status', filter: true },
        { field: 'region' },
        { field: 'subregion' },
        { field: 'area', filter: true },
        { field: 'population' },
        { field: 'fifa' },
        { field: 'startOfWeek' },
        { field: 'flag' },
    ]);

    // DefaultColDef sets props common to all Columns
    const defaultColDef = useMemo(() => ({
        sortable: true,
        filter: true,
        floatingFilter: true,
    }));

    // Example load data from server
    useEffect(() => {

    }, []);

    const onLoadData = () => {
        gridRef.current.api.showLoadingOverlay();
        setTimeout(() => {
            // 'https://www.ag-grid.com/example-assets/row-data.json'
            axios.get('https://restcountries.com/v3.1/all').then(res => {
                const newArr = rowData.concat(res.data);
                setRowData(newArr);
            })
        }, 500);
    }

    const onFilterTextBoxChanged = useCallback(() => {
        gridRef.current.api.setQuickFilter(
          document.getElementById('filter-text-box').value
        );
      }, []);

    return (
        <div>
            {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
            <div className="ag-theme-alpine" style={{ width: '100%', height: 'calc(100vh - 120px)' }}>
                <div className='rflex' style={{gap:100}}>
                    <button onClick={onLoadData}>{rowData.length ? 'Load more data' : 'Load data'}</button>
                    <input
                        type="text"
                        id="filter-text-box"
                        placeholder="Filter..."
                        onInput={onFilterTextBoxChanged}
                    />
                </div>
              
                <AgGridReact
                    ref={gridRef}
                    rowData={rowData} // Row Data for Rows
                    columnDefs={columnDefs} // Column Defs for Columns
                    defaultColDef={defaultColDef} // Default Column Properties
                    animateRows={true} // Optional - set to 'true' to have rows animate when sorted
                    pagination={true}
                    overlayNoRowsTemplate={'<span>No rows to display</span>'}
                    overlayLoadingTemplate={'<span class="ag-overlay-loading-center">Please wait while your rows are loading</span>'}
                    paginationPageSize={15}
                    enableBrowserTooltips
                    sideBar={true}
                />
            </div>
        </div>
    );
};

export default BasicGrid;