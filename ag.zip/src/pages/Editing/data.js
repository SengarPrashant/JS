export function getData() {
    return [
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'New York',
        country: 'USA',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Bob Harrison',
        gender: 'Male',
        address:
          '1197 Thunder Wagon Common, Cataract, RI, 02987-1016, US, (401) 747-0763',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Mary Wilson',
        gender: 'Female',
        age: 11,
        address: '3685 Rocky Glade, Showtucket, NU, X1E-9I0, CA, (867) 371-4215',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Zahid Khan',
        gender: 'Male',
        age: 12,
        address:
          '3235 High Forest, Glen Campbell, MS, 39035-6845, US, (601) 638-8186',
        city: 'Dublin',
        country: 'Ireland',
      },
      {
        name: 'Jerry Mane',
        gender: 'Male',
        age: 12,
        address:
          '2234 Sleepy Pony Mall , Drain, DC, 20078-4243, US, (202) 948-3634',
        city: 'Dublin',
        country: 'Ireland',
      },
    ];
  }