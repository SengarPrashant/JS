import React, { useCallback, useMemo, useRef, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import ColourCellRenderer from './colourCellRenderer.jsx';

const colors = ['Male', 'Female', 'Others'];

const data = Array.from(Array(20).keys()).map((val, index) => ({
  color1: colors[index % 3],
  color2: colors[index % 3],
  color3: colors[index % 3],
  description:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
}));

const Editing = () => {
  const containerStyle = useMemo(() => ({ width: '100%', height: '100%' }), []);
  const gridStyle = useMemo(() => ({ height: '100%', width: '100%' }), []);
  const [rowData, setRowData] = useState(data);
  const [columnDefs, setColumnDefs] = useState([
    {
      headerName: 'Text Editor',
      field: 'color1',
      cellRenderer: ColourCellRenderer,
      cellEditor: 'agTextCellEditor',
      cellEditorParams: {
        maxLength: 20,
      },
    },
    {
      headerName: 'Select Editor',
      field: 'color2',
      cellRenderer: ColourCellRenderer,
      cellEditor: 'agSelectCellEditor',
      cellEditorParams: {
        values: colors,
      },
    },
    {
      headerName: 'Rich Select Editor',
      field: 'color3',
      cellRenderer: ColourCellRenderer,
      cellEditor: 'agRichSelectCellEditor',
      cellEditorPopup: true,
      cellEditorParams: {
        values: colors,
        cellRenderer: ColourCellRenderer,
      },
    },
    {
      headerName: 'Large Text Editor',
      field: 'description',
      cellEditorPopup: true,
      cellEditor: 'agLargeTextCellEditor',
      cellEditorParams: {
        maxLength: 250,
        rows: 10,
        cols: 50,
      },
      flex: 2,
    },
  ]);
  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      resizable: true,
      editable: true,
    };
  }, []);

  return (
    <div style={containerStyle}>
      <div style={{ width: '100%', height: 'calc(100vh - 120px)' }} className="ag-theme-alpine">
        <AgGridReact
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
        ></AgGridReact>
      </div>
    </div>
  );
};

export default Editing